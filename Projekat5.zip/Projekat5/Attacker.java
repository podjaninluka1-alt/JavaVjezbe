package VjezbeXII;

public interface Attacker {
	int getEffectiveDamage();
}
