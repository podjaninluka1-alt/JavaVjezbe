package Vjezbe8;

public class Zaposleni {
	private int id;
	private String ime;
	private String prezime;
	private double plataPoSatu;
	private int ukupanBrojSati;
	private String pozicija;
	private int prekovremeniSati;
	private double bonus;

	public Zaposleni(int id, String ime, String prezime, double plataPoSatu, int ukupanBrojSati, String tip) {
		this.id = id;
		this.ime = ime;
		this.prezime = prezime;
		this.plataPoSatu = plataPoSatu;
		this.ukupanBrojSati = ukupanBrojSati;
		this.pozicija = (pozicija != null) ? pozicija.toLowerCase() : "nepoznat";
	}

	public void setPrekovremeniSati(int sati) {
		this.prekovremeniSati = sati;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	public double obracunajPlatu() {
		double plata = 0;

		switch (pozicija) {
		case "konobar":
			double osnovna = ukupanBrojSati * plataPoSatu;
			double prekovremeno = prekovremeniSati * (plataPoSatu * 1.2);
			plata = 4 * (osnovna + prekovremeno);
			break;

		case "kuvar":
			plata = 1500 + 4 * ukupanBrojSati * plataPoSatu;
			break;

		case "menadzer":
			plata = 1300 + 4 * ukupanBrojSati * plataPoSatu + bonus;
			break;

		default:
			System.out.println("Nepoznat tip zaposlenog!");
		}

		return plata;
	}

	@Override
	public String toString() {
		return "Zaposleni [id=" + id + ", ime=" + ime + ", prezime=" + prezime + ", plataPoSatu=" + plataPoSatu
				+ ", ukupanBrojSati=" + ukupanBrojSati + ", pozicija=" + pozicija + ", prekovremeniSati="
				+ prekovremeniSati + ", bonus=" + bonus + "]";
	}

	public String getTip() {
		return pozicija;
	}

	public int getId() {
		return id;
	}
}