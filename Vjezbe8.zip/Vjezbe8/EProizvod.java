package Vjezbe8;

import java.util.ArrayList;
import java.util.Scanner;

public class EProizvod {

	protected String opis;
	protected String sifra;
	protected double uvoznaCijena;

	public EProizvod(String opis, String sifra, double uvoznaCijena) {
		this.opis = opis;
		this.sifra = sifra;
		this.uvoznaCijena = uvoznaCijena;
	}

	public double izracunajMaloprodajnuCijenu() {
		return uvoznaCijena * 1.05;
	}

	public static void main(String[] args) {

	}

	String getTip() {
		if (sifra.startsWith("RA"))
			return "Racunari";
		if (sifra.startsWith("TE"))
			return "Telefoni";
		if (sifra.startsWith("TV"))
			return "TV";
		return "Nepoznato";

	}

	@Override
	public String toString() {
		return "EProizvod [opis=" + opis + ", sifra=" + sifra + ", uvoznaCijena=" + uvoznaCijena + "]";
	}

}
