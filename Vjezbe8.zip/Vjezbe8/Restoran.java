package Vjezbe8;

import java.util.ArrayList;

public class Restoran {
	private String naziv;
	private String adresa;
	private String PIB;
	private ArrayList<Zaposleni> zaposleni = new ArrayList<>();

	public Restoran(String naziv, String adresa, String PIB) {
		this.naziv = naziv;
		this.adresa = adresa;
		this.PIB = PIB;
	}

	public void dodajZaposlenog(Zaposleni z) {
		zaposleni.add(z);
	}

	public void ukloniZaposlenog(int id) {
		zaposleni.removeIf(z -> z.getId() == id);
	}

	public void prikaziSveZaposlene() {
		System.out.println("\n=== Spisak zaposlenih u restoranu ===");
		for (Zaposleni z : zaposleni) {
			System.out.println(z);
		}
	}

	public double ukupniTrosakPlata() {
		double suma = 0;
		for (Zaposleni z : zaposleni) {
			suma += z.obracunajPlatu();
		}
		return suma;
	}
}