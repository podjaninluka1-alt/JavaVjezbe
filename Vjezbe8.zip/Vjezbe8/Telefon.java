package Vjezbe8;

public class Telefon extends EProizvod {
	public Telefon(String opis, String sifra, double uvoznaCijena) {
		super(opis, sifra, uvoznaCijena);
	}

	private String operativniSistem;
	private double velicinaEkrana;

	public static void main(String[] args);

	public Telefon(String opis, String sifra, double uvoznaCijena, String os, double velicinaEkrana) {
		super(opis, sifra, uvoznaCijena);
		this.operativniSistem = os;
		this.velicinaEkrana = velicinaEkrana;
	}

	@Override
	public double izracunajMaloprodajnuCijenu() {
		double cijena = super.izracunajMaloprodajnuCijenu();
		if (velicinaEkrana > 6) {
			cijena *= 1.03;
		}
		return cijena;
	}

	@Override
	public String toString() {
		return "Telefon [operativniSistem=" + operativniSistem + ", velicinaEkrana=" + velicinaEkrana + "]";
	}
}
