package Vjezbe8;

public class testKlasa {

	public static void main(String[] args) {
		Restoran r = new Restoran("Mala Kuhinja", "Bulevar 12", "123456789");

		Zaposleni k1 = new Zaposleni(1, "Marko", "Markovic", 5.5, 40, "konobar");
		k1.setPrekovremeniSati(5);

		Zaposleni k2 = new Zaposleni(2, "Jelena", "Jovic", 8.0, 45, "kuvar");

		Zaposleni m1 = new Zaposleni(3, "Nikola", "Nikolic", 10.0, 35, "menadzer");
		m1.setBonus(200);

		r.dodajZaposlenog(k1);
		r.dodajZaposlenog(k2);
		r.dodajZaposlenog(m1);

		r.prikaziSveZaposlene();

		System.out.printf("\nUkupan trošak plata: %.2f €\n", r.ukupniTrosakPlata());
	}
}
