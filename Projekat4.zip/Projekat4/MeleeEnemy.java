package Projekat4;

public class MeleeEnemy extends Enemy {
	    public MeleeEnemy(String type, int x, int y, Collidable c, int damage, int health) {
	        super(type, x, y, c, damage, health);
	    }
	}

