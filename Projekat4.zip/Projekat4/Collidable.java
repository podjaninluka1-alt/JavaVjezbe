package Projekat4;

public interface Collidable {
	 boolean intersects(Collidable other);

	
}
