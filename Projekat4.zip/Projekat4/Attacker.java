package Projekat4;

public interface Attacker {
	    int getEffectiveDamage();
	}

