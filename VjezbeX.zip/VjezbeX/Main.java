package Vjezbex;

public class Main {
	public static void main(String[] args) {

		Vozilo b = new Bicikl("B1", 20);
		Vozilo m = new Motor("M1", 60);
		Vozilo a = new Automobil("A1", 90);

		double d = 15;

		System.out.println("Bicikl:");
		b.info();
		System.out.println("Vrijeme: " + b.izracunajVrijemeDostave(d) + " h\n");

		System.out.println("Motor:");
		m.info();
		System.out.println("Vrijeme: " + m.izracunajVrijemeDostave(d) + " h\n");

		System.out.println("Auto:");
		a.info();
		System.out.println("Vrijeme: " + a.izracunajVrijemeDostave(d) + " h\n");
	}
}