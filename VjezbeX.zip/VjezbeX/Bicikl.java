package Vjezbex;

public class Bicikl extends Vozilo implements Ekonomican {

	public Bicikl(String id, double maxBrzina) {
		super(id, maxBrzina);
	}

	@Override
	public double potrosnjaPoKm() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double izracunajVrijemeDostave(double udaljenost) {
		// TODO Auto-generated method stub
		return 0;
	}
}
