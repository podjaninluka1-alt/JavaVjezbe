package Vjezbex;

public class Motor extends Vozilo implements Ekonomican {

	public Motor(String id, double maxBrzina) {
		super(id, maxBrzina);
	}

	@Override
	public double izracunajVrijemeDostave(double udaljenost) {
		// TODO Auto-generated method stub
		return 0;
	}
}
