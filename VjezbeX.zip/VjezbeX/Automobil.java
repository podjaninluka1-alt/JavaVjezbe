package Vjezbex;

public class Automobil extends Vozilo implements Ekonomican {
	public Automobil(String id, double maxBrzina) {
		super(id, maxBrzina);
	}

	@Override
	public double potrosnjaPoKm() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double izracunajVrijemeDostave(double udaljenost) {
		// TODO Auto-generated method stub
		return 0;
	}
}
